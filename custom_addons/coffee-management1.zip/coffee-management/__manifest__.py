# -*- coding: utf-8 -*-
{
    "name": "Coffee Management",
    "version": "1.0",
    "author": "Coffee Team",
    "category": "Manufacturing/Manufacturing",
    "summary": "Manage the entire coffee production chain from arrival to delivery.",
    "description": """
This module allows you to manage your coffee production and consumption.
It includes a Coffee Production and Consumption journal, a Coffee Production and Consumption report, and a Coffee Production and Consumption dashboard.
    """,
    # This is the critical section that forces Odoo to load other modules first.
    'depends': [
        'stock',    # The 'product' module depends on 'stock', so including it ensures the full product/inventory app is loaded.
        'mrp',      # For manufacturing orders
        'purchase', # Recommended for future integration
        'sale',     # Recommended for future integration
        'product',  # For product templates
        'contacts', # For customer and supplier management
        'account',  # For accounting integration
    ],
    "data": [
        'security/ir.model.access.csv',
        # 3. Load other data and views.
        'data/coffee_data.xml',
        'views/product_template_views.xml',
        'views/coffee_arrival_views.xml',
        'views/coffee_quality_views.xml',
        'views/coffee_weight_views.xml',
        'views/coffee_stock_receiving_views.xml',
        'views/coffee_stock_issue_views.xml',
        'views/coffee_contract_views.xml',
        'views/menuitems.xml',
        'reports/coffee_reports.xml',
        'reports/coffee_report_templates.xml',
    ],
    'license': 'LGPL-3',
    "installable": True,
    "application": True,
    "auto_install": False,
}