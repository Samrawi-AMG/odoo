# models/__init__.py

# -*- coding: utf-8 -*-
from . import coffee_arrival
from . import coffee_contract
from . import coffee_contract_line
from . import coffee_quality
from . import coffee_stock_issue
from . import coffee_stock_receiving
from . import coffee_weight
from . import coffee_weight_log
from . import mrp_production_extension
from . import product_extension
from . import product_template_extension
from . import res_partner_extension
from . import stock_picking_extension
from . import stock_rule_extension # From previous fixes
from . import account_move_extension # <-- ADD THIS LINE