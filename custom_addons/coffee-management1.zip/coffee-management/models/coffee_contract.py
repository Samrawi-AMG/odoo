# models/coffee_contract.py

# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import UserError

class CoffeeContract(models.Model):
    _name = 'coffee.contract'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Coffee Contract'
    _rec_name = 'contract_number'

    contract_number = fields.Char(string='Contract Number', required=True, copy=False, readonly=True, default='New')
    buyer_id = fields.Many2one('res.partner', string='Buyer Name', domain=[('customer_rank', '>', 0)], required=True)
    contract_date = fields.Date(string='Date of Contract', default=fields.Date.today(), required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done'),
        ('cancelled', 'Cancelled'),
    ], string='Status', default='draft', tracking=True)

    contract_line_ids = fields.One2many(
        'coffee.contract.line',
        'contract_id',
        string='Contract Lines',
        copy=True,
        auto_join=True
    )

    picking_ids = fields.One2many('stock.picking', 'coffee_contract_id', string='Pickings')
    delivery_count = fields.Integer(string='Delivery Orders', compute='_compute_picking_ids')

    # === NEW INVOICING FIELDS ===
    invoice_ids = fields.One2many('account.move', 'coffee_contract_id', string='Invoices')
    invoice_count = fields.Integer(string='Invoice Count', compute='_compute_invoice_count')
    # === END OF NEW FIELDS ===

    delivered_kg = fields.Float(string="Delivered KG", compute='_compute_fulfillment', store=True)
    fulfillment_percentage = fields.Float(string="Fulfillment (%)", compute='_compute_fulfillment', store=True)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('contract_number', 'New') == 'New':
                vals['contract_number'] = self.env['ir.sequence'].next_by_code('coffee.contract') or 'New'
        return super().create(vals_list)

    @api.depends('picking_ids')
    def _compute_picking_ids(self):
        for contract in self:
            contract.delivery_count = len(contract.picking_ids)
     # === NEW INVOICING METHODS ===
    @api.depends('invoice_ids')
    def _compute_invoice_count(self):
        for contract in self:
            contract.invoice_count = len(contract.invoice_ids)

    def action_create_invoice(self):
        """Creates a draft customer invoice from the contract lines."""
        self.ensure_one()
        
        # --- Prepare the main invoice values ---
        invoice_vals = {
            'partner_id': self.buyer_id.id,
            'move_type': 'out_invoice',  # This specifies it's a Customer Invoice
            'invoice_date': fields.Date.context_today(self),
            'invoice_origin': self.contract_number,
            'coffee_contract_id': self.id, # Link back to this contract
        }

        # --- Prepare the invoice lines from contract lines ---
        invoice_line_ids = []
        KG_PER_TON = 1000
        LB_PER_KG = 2.20462 # Conversion factor for price

        for line in self.contract_line_ids:
            # The invoice needs the quantity in the product's default UoM (KG)
            quantity_in_kg = line.quantity_tons * KG_PER_TON
            
            # The invoice needs the price per UoM (KG), but the contract is in USD/LB
            price_per_kg = line.unit_price_usd_per_lb * LB_PER_KG

            invoice_line_ids.append((0, 0, {
                'name': line.name,
                'product_id': line.product_id.id,
                'quantity': quantity_in_kg,
                'product_uom_id': line.product_id.uom_id.id,
                'price_unit': price_per_kg,
            }))
        
        invoice_vals['invoice_line_ids'] = invoice_line_ids

        # --- Create and return the invoice ---
        new_invoice = self.env['account.move'].create(invoice_vals)

        # Return an action to open the new invoice in a new window
        return {
            'type': 'ir.actions.act_window',
            'name': _('Customer Invoice'),
            'res_model': 'account.move',
            'res_id': new_invoice.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def action_view_invoices(self):
        """Action to open the list of invoices related to this contract."""
        return {
            'name': _('Invoices'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.invoice_ids.ids)],
        }
    # === END OF NEW METHODS ===
            
    # === CORRECTED DEPENDS AND METHOD LOGIC FOR ODOO 17 ===
    @api.depends('contract_line_ids.quantity_tons', 'picking_ids.state', 'picking_ids.move_ids.quantity')
    def _compute_fulfillment(self):
        KG_PER_TON = 1000
        for contract in self:
            total_ordered_kg = sum(line.quantity_tons * KG_PER_TON for line in contract.contract_line_ids)
            total_delivered_kg = 0.0

            done_pickings = contract.picking_ids.filtered(
                lambda p: p.picking_type_code == 'outgoing' and p.state == 'done'
            )
            for picking in done_pickings:
                # Use 'quantity' instead of 'quantity_done' for Odoo 17
                total_delivered_kg += sum(
                    move.quantity for move in picking.move_ids 
                    if move.product_id in contract.contract_line_ids.mapped('product_id')
                )

            contract.delivered_kg = total_delivered_kg
            if total_ordered_kg > 0:
                contract.fulfillment_percentage = (total_delivered_kg / total_ordered_kg) * 100.0
            else:
                contract.fulfillment_percentage = 0.0

    def action_view_delivery(self):
        return {
            'name': _('Delivery Orders'),
            'type': 'ir.actions.act_window',
            'res_model': 'stock.picking',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.picking_ids.filtered(lambda p: p.picking_type_code == 'outgoing').ids)],
        }

    def action_confirm_contract(self):
        self.ensure_one()
        if not self.contract_line_ids:
            raise UserError(_("You cannot confirm a contract with no lines."))

        warehouse = self.env['stock.warehouse'].search([('company_id', '=', self.env.company.id)], limit=1)
        if not warehouse:
            raise UserError(_("No warehouse is configured for this company."))
        picking_type = warehouse.out_type_id

        picking = self.env['stock.picking'].create({
            'partner_id': self.buyer_id.id,
            'picking_type_id': picking_type.id,
            'location_id': picking_type.default_location_src_id.id,
            'location_dest_id': self.env.ref('stock.stock_location_customers').id,
            'origin': self.contract_number,
            'coffee_contract_id': self.id,
        })

        KG_PER_TON = 1000
        for line in self.contract_line_ids:
            self.env['stock.move'].create({
                'name': line.name,
                'product_id': line.product_id.id,
                'product_uom_qty': line.quantity_tons * KG_PER_TON,
                'product_uom': line.product_id.uom_id.id,
                'picking_id': picking.id,
                'location_id': picking.location_id.id,
                'location_dest_id': picking.location_dest_id.id,
            })

        picking.action_confirm()
        self.write({'state': 'confirmed'})

    def action_cancel(self):
        self.picking_ids.action_cancel()
        self.write({'state': 'cancelled'})