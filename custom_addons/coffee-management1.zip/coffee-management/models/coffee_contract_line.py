# -*- coding: utf-8 -*-
from odoo import fields, models, api

class CoffeeContractLine(models.Model):
    _name = 'coffee.contract.line'
    _description = 'Coffee Contract Line'

    contract_id = fields.Many2one(
        'coffee.contract',
        string='Contract Reference',
        required=True,
        ondelete='cascade',
        index=True,
        copy=False
    )
    product_id = fields.Many2one(
        'product.product',
        string='Coffee Product',
        required=True,
        domain="[('is_coffee_product', '=', True), ('sale_ok', '=', True)]"
    )
    name = fields.Text(string='Description', required=True)
    quantity_tons = fields.Float(string='Quantity (Tons)', required=True, default=1.0)
    unit_price_usd_per_lb = fields.Float(string='Unit Price (USD per LB)', required=True)

    # Automatically set the description when the product is selected
    @api.onchange('product_id')
    def _onchange_product_id(self):
        if self.product_id:
            self.name = self.product_id.get_product_multiline_description_sale()