from odoo import fields, models, api, _
from odoo.exceptions import ValidationError, UserError


class CoffeeQualityEvaluation(models.Model):
    _name = 'coffee.quality.evaluation'
    _description = 'Coffee Quality Evaluation'
    _rec_name = 'arrival_id'

    arrival_id = fields.Many2one('coffee.arrival', string='Arrival Record', required=True, ondelete='cascade')
    moisture_content = fields.Float(string='Moisture Content (%)', required=True, default=0.0)
    screen_percentage = fields.Float(string='Screen (%)', required=True, default=0.0)

    # Raw Attributes
    primary_defect = fields.Float(string='Primary Defect (15%)', required=True, default=0.0)
    secondary_defect = fields.Float(string='Secondary Defect (15%)', required=True, default=0.0)
    # Ensure this is defined as Selection if it's not already
    odour = fields.Selection([
        ('clean', 'Clean'),
        ('light', 'Light'),
        ('moderate', 'Moderate'),
        ('strong', 'Strong'),
    ], string='Odour (10%)', required=True, default='clean') # Adjusted string to reflect its weight in score

    # Cup Attributes
    cup_clean = fields.Float(string='Cup Clean (15%)', required=True, default=0.0)
    acidity = fields.Float(string='Acidity (15%)', required=True, default=0.0)
    body = fields.Float(string='Body (15%)', required=True, default=0.0)
    flavor = fields.Float(string='Flavor (15%)', required=True, default=0.0)

    total_score = fields.Float(string='Total Score (%)', compute='_compute_total_score', store=True)
    amg_grade = fields.Selection([
        ('UG', 'UG'),
        ('G5', 'G5'),
        ('G4', 'G4'),
        ('G3', 'G3'),
        ('G2', 'G2'),
        ('G1', 'G1'),
    ], string='AMG Grade', compute='_compute_amg_grade', store=True)

    @api.depends('primary_defect', 'secondary_defect', 'odour', 'cup_clean', 'acidity', 'body', 'flavor')
    def _compute_total_score(self):
        # Define a mapping for odour selection values to numerical defect points.
        # Assuming 'clean' means 0 defect, 'strong' means max defect (10).
        odour_defect_mapping = {
            'clean': 0.0,
            'light': 3.0,  # Example defect points for 'light' odour
            'moderate': 6.0, # Example defect points for 'moderate' odour
            'strong': 10.0, # Example defect points for 'strong' odour (max points for deduction)
        }

        for record in self:
            # Get the numerical defect value for odour, defaulting to 0 if not found
            # This handles cases where 'odour' might be False/None or not in the mapping
            odour_defect_value = odour_defect_mapping.get(record.odour, 0.0)

            # Calculate total score. Defects are subtracted from their max possible points,
            # while cup attributes are added directly.
            record.total_score = (
                    record.primary_defect +
                    record.secondary_defect +
                    (10 - odour_defect_value) + # Use the numerical defect value here
                    record.cup_clean +
                    record.acidity +
                    record.body +
                    record.flavor
            )

    @api.depends('total_score')
    def _compute_amg_grade(self):
        for record in self:
            if 15 <= record.total_score <= 30:
                record.amg_grade = 'UG'
            elif 31 <= record.total_score <= 46:
                record.amg_grade = 'G5'
            # Correcting the condition here for 47-62, if 62 is inclusive
            elif 47 <= record.total_score <= 62:
                record.amg_grade = 'G4'
            elif 63 <= record.total_score <= 74:
                record.amg_grade = 'G3'
            elif 75 <= record.total_score <= 84:
                record.amg_grade = 'G2'
            elif record.total_score >= 85:
                record.amg_grade = 'G1'
            else:
                record.amg_grade = False # No grade if score outside defined ranges

    @api.constrains('amg_grade')
    def _check_amg_grade_for_downstream(self):
        for record in self:
            if record.amg_grade == 'UG':
                record.arrival_id.state = 'ug_grade'
                raise UserError(
                    _("AMG Grade is 'UG'. All downstream steps (Weight, Stock, Contract) are disabled for this coffee arrival."))
            else:
                # Update product with AMG grade
                if record.arrival_id.product_id:
                    record.arrival_id.product_id.sudo().write({
                        'amg_grade': record.amg_grade,
                        'is_coffee_product': True
                    })
                
                # Ensure the state only changes to 'quality_evaluated' if it's not already 'done' or 'ug_grade'
                if record.arrival_id.state not in ('done', 'ug_grade'):
                    record.arrival_id.state = 'quality_evaluated'

    @api.onchange('moisture_content')
    def _onchange_moisture_content(self):
        if self.moisture_content > 12:  # Example threshold for high moisture
            # Returns a warning, not an error, allowing the user to proceed if desired
            return {'warning': {
                'title': "Moisture Warning",
                'message': "Moisture content is high. Consider potential quality issues for this coffee."
            }}
