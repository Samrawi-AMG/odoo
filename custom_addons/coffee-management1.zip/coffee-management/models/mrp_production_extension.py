# -*- coding: utf-8 -*-
from odoo import fields, models

class MrpProduction(models.Model):
    """
    Inherits mrp.production to add a direct link to a coffee.contract.
    This provides traceability from the manufacturing process back to the
    commercial agreement that triggered it.
    """
    _inherit = 'mrp.production'

    coffee_contract_id = fields.Many2one(
        'coffee.contract',
        string='Source Coffee Contract',
        help="The coffee contract that this manufacturing order fulfills.",
        copy=False,
        index=True,
        readonly=True
    )