# coffee_system/models/product_extension.py
from odoo import fields, models


class ProductProduct(models.Model):
    _inherit = 'product.product'

    weight_per_bag = fields.Float(string='Weight per Bag (KG)', default=1.0,
                                help="Specify the standard weight of one bag of this coffee product in KG.")
    esex_grade = fields.Selection([
        ('UG', 'UG'),
        ('G5', 'G5'), 
        ('G4', 'G4'),
        ('G3', 'G3'),
        ('G2', 'G2'),
        ('G1', 'G1'),
    ], string='ESEX Grade', help="Original grade from supplier")
    amg_grade = fields.Selection([
        ('UG', 'UG'),
        ('G5', 'G5'),
        ('G4', 'G4'),
        ('G3', 'G3'),
        ('G2', 'G2'),
        ('G1', 'G1'),
    ], string='AMG Grade', help="Internal grading based on quality evaluation")
    is_coffee_product = fields.Boolean(string='Is Coffee Product')
