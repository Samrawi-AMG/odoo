# -*- coding: utf-8 -*-
from odoo import fields, models, api

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    # --- Coffee Configuration Fields ---
    # We add these fields directly to the product template to make it the single source of truth.

    # We use Odoo's Product Attribute Values for configuration.
    # First, you must go to Inventory -> Configuration -> Product Attributes
    # and create attributes named 'Coffee Type', 'Coffee Origin', and 'Coffee Grade'.
    # Then you can add values like 'Washed', 'Guji', 'G1' to them.

    coffee_type_id = fields.Many2one(
        'product.attribute.value',
        string='Coffee Type',
        domain="[('attribute_id.name', '=', 'Coffee Type')]",
        help="Select the type (e.g., Washed, Unwashed) for this coffee product."
    )
    coffee_origin_id = fields.Many2one(
        'product.attribute.value',
        string='Coffee Origin',
        domain="[('attribute_id.name', '=', 'Coffee Origin')]",
        help="Select the origin (e.g., Guji, Sidamo) for this coffee product."
    )
    coffee_grade_id = fields.Many2one(
        'product.attribute.value',
        string='Coffee Grade',
        domain="[('attribute_id.name', '=', 'Coffee Grade')]",
        help="Select the grade (e.g., G1, G2) for this coffee product."
    )

    # To make searching easier, we can add a boolean to identify coffee products
    is_coffee_product = fields.Boolean(
        string="Is a Coffee Product",
        default=False,
        help="Check this box if this product is a coffee-related item. This helps in filtering."
    )