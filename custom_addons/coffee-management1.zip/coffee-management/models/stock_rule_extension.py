# models/stock_rule_extension.py

from odoo import models

class StockRule(models.Model):
    _inherit = 'stock.rule'

    def _prepare_mo_vals(self, product_id, product_qty, product_uom, location_id, name, origin, company_id, values, bom):
        """
        Overrides the standard method to inject the coffee_contract_id into the
        Manufacturing Order values.
        """
        # Get the standard values from the super method
        mo_vals = super()._prepare_mo_vals(product_id, product_qty, product_uom, location_id, name, origin, company_id, values, bom)

        # The 'origin' of the MO is typically the name of the source document
        # that triggered the MTO rule, which in this case is the Delivery Order.
        if origin:
            # Find the stock.picking (Delivery Order) using the origin name
            picking = self.env['stock.picking'].search([('name', '=', origin)], limit=1)
            if picking and picking.coffee_contract_id:
                # If the picking is found and linked to a contract, add it to the MO
                mo_vals['coffee_contract_id'] = picking.coffee_contract_id.id

        return mo_vals